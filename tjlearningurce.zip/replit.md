# TJLearningHub

A professional educational document marketplace by Tr. John where students and teachers browse, purchase, and download study materials.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/tjlearninghub run dev` — run the frontend (port 24802)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string
- Optional env: `SESSION_SECRET` — secret for admin session cookie (defaults to dev value)
- Optional env: `ADMIN_USERNAME` / `ADMIN_PASSWORD` — admin credentials (defaults: admin / tjlearning2024)

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite + Tailwind CSS + shadcn/ui, wouter routing
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Sessions: cookie-session (admin auth)
- File storage: Replit Object Storage (GCS-backed presigned URLs)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml` — API contract source of truth
- `lib/db/src/schema/` — Drizzle table definitions (documents, categories, download_tokens)
- `artifacts/api-server/src/routes/` — Express route handlers
- `artifacts/tjlearninghub/src/` — React frontend (pages, components, layout)
- `artifacts/api-server/src/lib/objectStorage.ts` — GCS/object storage service

## Architecture decisions

- Admin auth uses cookie-session (server-side sessions) rather than JWT — simpler for a single-admin setup.
- LipaLink payment is external: "Buy Now" redirects to the document's `lipaLinkUrl`. After payment, the user lands on `/download/:token` — the token is validated server-side against `download_tokens` table.
- Document files are stored via Replit Object Storage (presigned URL upload flow); `fileUrl` in the DB stores the object path.
- Price is stored as `numeric(10,2)` in PostgreSQL; all routes cast it to `parseFloat` for JSON responses.
- Admin credentials are env-var configurable with safe defaults for dev.

## Product

- **Public marketplace**: homepage with hero, featured docs, search, categories; full document browsing with filters; LipaLink payment redirect; download page with token validation
- **Admin dashboard**: secure login, document CRUD (create/edit/delete with file uploads), category management, download stats

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- After any OpenAPI spec change, run codegen before using the updated types.
- The `numeric` price column comes back as a string from Drizzle — always `parseFloat` it in route handlers before sending JSON.
- Orval generates `<OperationIdPascal>Params` Zod schemas that collide with TypeScript types when query params are present — use path-only params or rename operationIds to avoid TS2308 errors.
- Run `pnpm run typecheck:libs` after changing `lib/db/src/schema/` so API server imports pick up the new exports.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details

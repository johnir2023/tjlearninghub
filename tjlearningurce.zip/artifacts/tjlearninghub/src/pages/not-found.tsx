import { PublicLayout } from "@/components/layout/PublicLayout";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { FileQuestion, ArrowLeft } from "lucide-react";

export default function NotFound() {
  return (
    <PublicLayout>
      <div className="flex-1 flex flex-col items-center justify-center text-center p-4 py-20 min-h-[calc(100vh-16rem)]">
        <div className="bg-primary/5 p-6 rounded-full mb-6">
          <FileQuestion className="h-16 w-16 text-primary" />
        </div>
        <h1 className="text-5xl font-bold tracking-tight text-foreground mb-4">404</h1>
        <h2 className="text-2xl font-semibold text-muted-foreground mb-6">Page Not Found</h2>
        <p className="max-w-md text-muted-foreground mb-8">
          The page you are looking for doesn't exist or has been moved. 
          Please check the URL or navigate back to the homepage.
        </p>
        <Link href="/">
          <Button size="lg" className="h-12 px-8">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
          </Button>
        </Link>
      </div>
    </PublicLayout>
  );
}

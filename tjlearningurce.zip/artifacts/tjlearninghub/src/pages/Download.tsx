import { PublicLayout } from "@/components/layout/PublicLayout";
import { useGetDownload, getGetDownloadQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Download as DownloadIcon, CheckCircle2, AlertCircle, FileText, Loader2 } from "lucide-react";
import { useParams, Link } from "wouter";

export default function Download() {
  const params = useParams();
  const token = params.token || "";

  const { data: downloadInfo, isLoading, isError, error } = useGetDownload(token, {
    query: {
      enabled: !!token,
      queryKey: getGetDownloadQueryKey(token),
      retry: false, // Don't retry 404s
    }
  });

  return (
    <PublicLayout>
      <div className="flex-1 flex flex-col items-center justify-center p-4 bg-muted/10 min-h-[calc(100vh-16rem)]">
        <div className="w-full max-w-md">
          {isLoading ? (
            <Card className="shadow-lg border-border">
              <CardContent className="pt-10 pb-10 flex flex-col items-center text-center space-y-4">
                <Loader2 className="h-12 w-12 text-primary animate-spin" />
                <h2 className="text-xl font-semibold">Verifying your purchase...</h2>
                <p className="text-muted-foreground text-sm">Please wait while we prepare your download.</p>
              </CardContent>
            </Card>
          ) : isError ? (
            <Card className="shadow-lg border-destructive/20">
              <CardHeader className="text-center pb-2">
                <div className="mx-auto bg-destructive/10 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                  <AlertCircle className="h-8 w-8 text-destructive" />
                </div>
                <CardTitle className="text-2xl">Download Error</CardTitle>
                <CardDescription className="text-base">
                  We couldn't process this download request.
                </CardDescription>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-muted-foreground text-sm">
                  The link may have expired, or the token is invalid. If you just made a payment and see this, please contact support.
                </p>
              </CardContent>
              <CardFooter className="flex justify-center pt-2 pb-6">
                <Link href="/marketplace">
                  <Button variant="outline">Return to Marketplace</Button>
                </Link>
              </CardFooter>
            </Card>
          ) : downloadInfo ? (
            <Card className="shadow-lg border-secondary/20 overflow-hidden">
              <div className="bg-secondary/10 px-6 py-8 text-center border-b border-secondary/20">
                <div className="mx-auto bg-secondary w-16 h-16 rounded-full flex items-center justify-center mb-4 shadow-sm">
                  <CheckCircle2 className="h-8 w-8 text-secondary-foreground" />
                </div>
                <h1 className="text-2xl font-bold text-foreground mb-2">Payment Successful!</h1>
                <p className="text-muted-foreground">Thank you for your purchase.</p>
              </div>
              
              <CardContent className="p-6">
                <div className="flex items-start gap-4 mb-6 p-4 rounded-lg bg-muted/50 border border-border">
                  {downloadInfo.thumbnailUrl ? (
                    <img 
                      src={downloadInfo.thumbnailUrl} 
                      alt="Thumbnail" 
                      className="w-16 h-16 rounded object-cover shadow-sm bg-background flex-shrink-0"
                    />
                  ) : (
                    <div className="w-16 h-16 rounded bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <FileText className="h-8 w-8 text-primary/60" />
                    </div>
                  )}
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-muted-foreground mb-1 uppercase tracking-wider">Ready to download</p>
                    <h3 className="font-bold text-lg leading-tight text-foreground truncate">{downloadInfo.title}</h3>
                  </div>
                </div>

                <a href={downloadInfo.fileUrl} download target="_blank" rel="noopener noreferrer" className="block w-full">
                  <Button className="w-full h-14 text-lg bg-secondary hover:bg-secondary/90 text-secondary-foreground shadow-md hover:shadow-lg transition-all active:scale-[0.98]">
                    <DownloadIcon className="mr-2 h-5 w-5" />
                    Download File Now
                  </Button>
                </a>
              </CardContent>
              
              <CardFooter className="bg-muted/20 px-6 py-4 flex justify-center text-sm text-muted-foreground">
                <p>Having trouble? <a href="#" className="text-primary hover:underline">Contact Support</a></p>
              </CardFooter>
            </Card>
          ) : null}
        </div>
      </div>
    </PublicLayout>
  );
}

import { PublicLayout } from "@/components/layout/PublicLayout";
import { Link, useLocation } from "wouter";
import { useListDocuments, getListDocumentsQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { DocumentCard } from "@/components/DocumentCard";
import { ArrowRight, BookOpen, Search, ShieldCheck, Zap, GraduationCap } from "lucide-react";
import { useState } from "react";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  
  const { data: featuredDocs, isLoading } = useListDocuments({ featured: true }, {
    query: {
      queryKey: getListDocumentsQueryKey({ featured: true })
    }
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLocation(`/marketplace?search=${encodeURIComponent(searchQuery.trim())}`);
    } else {
      setLocation(`/marketplace`);
    }
  };

  return (
    <PublicLayout>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-background pt-16 md:pt-24 pb-20 lg:pt-32 lg:pb-28">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-primary/10 via-background to-background -z-10" />
        <div className="container mx-auto px-4 flex flex-col items-center text-center">
          <div className="inline-flex items-center rounded-full border border-primary/20 bg-primary/5 px-3 py-1 text-sm font-medium text-primary mb-8">
            <span className="flex h-2 w-2 rounded-full bg-primary mr-2 animate-pulse"></span>
            East Africa's Trusted Academic Resource
          </div>
          
          <h1 className="max-w-4xl text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-foreground mb-6">
            Unlock Your Potential with <br className="hidden sm:block" />
            <span className="text-primary">Premium Study Materials</span>
          </h1>
          
          <p className="max-w-2xl text-lg md:text-xl text-muted-foreground mb-10 leading-relaxed">
            Curated notes, past papers, and revision guides from top educators. Instantly accessible, professionally formatted, and designed for success.
          </p>
          
          <div className="w-full max-w-md mx-auto mb-10">
            <form onSubmit={handleSearch} className="relative flex items-center">
              <Search className="absolute left-4 h-5 w-5 text-muted-foreground" />
              <Input 
                type="search" 
                placeholder="Search for notes, past papers, subjects..." 
                className="pl-12 pr-24 h-14 rounded-full text-base bg-background shadow-sm border-border/80 focus-visible:ring-primary/50"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Button type="submit" size="sm" className="absolute right-2 rounded-full h-10 px-4">
                Search
              </Button>
            </form>
          </div>
          
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link href="/marketplace">
              <Button size="lg" className="h-12 px-8 text-base font-semibold shadow-sm hover:shadow-md transition-shadow">
                Browse Marketplace <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="h-16 w-16 rounded-2xl bg-primary/10 text-primary flex items-center justify-center">
                <ShieldCheck className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold text-foreground">Verified Quality</h3>
              <p className="text-muted-foreground">Every document is reviewed by experienced educators to ensure accuracy and curriculum alignment.</p>
            </div>
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="h-16 w-16 rounded-2xl bg-secondary/10 text-secondary flex items-center justify-center">
                <Zap className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold text-foreground">Instant Access</h3>
              <p className="text-muted-foreground">Pay via secure mobile money (M-Pesa/Airtel Money) and download your materials immediately.</p>
            </div>
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="h-16 w-16 rounded-2xl bg-accent/10 text-accent flex items-center justify-center">
                <GraduationCap className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold text-foreground">Exam Focused</h3>
              <p className="text-muted-foreground">Materials structured specifically to help you master concepts and excel in your final examinations.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Documents */}
      <section className="py-16 md:py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
            <div className="max-w-2xl">
              <h2 className="text-3xl font-bold text-foreground mb-3">Featured Resources</h2>
              <p className="text-muted-foreground text-lg">Top-rated study materials selected by Tr. John.</p>
            </div>
            <Link href="/marketplace">
              <Button variant="outline" className="shrink-0 font-medium border-border/80">
                View All Resources <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {isLoading ? (
              Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="flex flex-col space-y-3">
                  <Skeleton className="h-[200px] w-full rounded-xl" />
                  <Skeleton className="h-4 w-[250px]" />
                  <Skeleton className="h-4 w-[200px]" />
                  <div className="pt-4 flex justify-between">
                    <Skeleton className="h-6 w-16" />
                    <Skeleton className="h-6 w-20" />
                  </div>
                </div>
              ))
            ) : featuredDocs?.length ? (
              featuredDocs.slice(0, 4).map((doc) => (
                <DocumentCard key={doc.id} document={doc} />
              ))
            ) : (
              <div className="col-span-full py-12 text-center border rounded-xl border-dashed border-border">
                <BookOpen className="mx-auto h-10 w-10 text-muted-foreground/50 mb-4" />
                <h3 className="text-lg font-medium text-foreground mb-1">No featured documents</h3>
                <p className="text-muted-foreground">Check out our marketplace for all available materials.</p>
              </div>
            )}
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}

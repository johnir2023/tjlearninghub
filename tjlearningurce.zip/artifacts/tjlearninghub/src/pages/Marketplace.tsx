import { PublicLayout } from "@/components/layout/PublicLayout";
import { useListDocuments, useListCategories, getListDocumentsQueryKey } from "@workspace/api-client-react";
import { DocumentCard } from "@/components/DocumentCard";
import { Input } from "@/components/ui/input";
import { Search, Filter, X } from "lucide-react";
import { useState, useEffect } from "react";
import { useLocation, useSearch } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";

export default function Marketplace() {
  const searchString = useSearch();
  const searchParams = new URLSearchParams(searchString);
  const initialSearch = searchParams.get("search") || "";
  const initialCategory = searchParams.get("category") || "";

  const [searchQuery, setSearchQuery] = useState(initialSearch);
  const [debouncedSearch, setDebouncedSearch] = useState(initialSearch);
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory);
  const [, setLocation] = useLocation();

  // Debounce search
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(searchQuery);
    }, 500);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Update URL when filters change
  useEffect(() => {
    const params = new URLSearchParams();
    if (debouncedSearch) params.set("search", debouncedSearch);
    if (selectedCategory) params.set("category", selectedCategory);
    
    const newSearch = params.toString();
    setLocation(newSearch ? `/marketplace?${newSearch}` : "/marketplace", { replace: true });
  }, [debouncedSearch, selectedCategory, setLocation]);

  const { data: documents, isLoading: isLoadingDocs } = useListDocuments(
    { 
      search: debouncedSearch || undefined, 
      category: selectedCategory || undefined 
    },
    {
      query: {
        queryKey: getListDocumentsQueryKey({ search: debouncedSearch || undefined, category: selectedCategory || undefined })
      }
    }
  );

  const { data: categories, isLoading: isLoadingCats } = useListCategories();

  const handleClearFilters = () => {
    setSearchQuery("");
    setDebouncedSearch("");
    setSelectedCategory("");
  };

  const hasActiveFilters = debouncedSearch !== "" || selectedCategory !== "";

  return (
    <PublicLayout>
      <div className="bg-muted/30 border-b border-border">
        <div className="container mx-auto px-4 py-8 md:py-12">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Resource Marketplace</h1>
          <p className="text-muted-foreground text-lg max-w-2xl">
            Browse our extensive collection of high-quality educational materials. Filter by subject or search for specific topics.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 flex flex-col md:flex-row gap-8">
        {/* Sidebar Filters */}
        <aside className="w-full md:w-64 shrink-0 space-y-6">
          <div className="space-y-4">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <Filter className="w-5 h-5 text-primary" /> Filters
            </h3>
            
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 bg-background"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  <X className="h-3 w-3" />
                </button>
              )}
            </div>

            {hasActiveFilters && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleClearFilters}
                className="w-full text-muted-foreground hover:text-foreground h-8"
              >
                Clear all filters
              </Button>
            )}
          </div>

          <div className="space-y-3">
            <h4 className="font-medium text-sm text-foreground/80 uppercase tracking-wider">Categories</h4>
            {isLoadingCats ? (
              <div className="space-y-2">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Skeleton key={i} className="h-8 w-full rounded-md" />
                ))}
              </div>
            ) : (
              <div className="flex flex-col gap-1">
                <button
                  onClick={() => setSelectedCategory("")}
                  className={`text-left px-3 py-2 text-sm rounded-md transition-colors ${
                    selectedCategory === "" 
                      ? "bg-primary text-primary-foreground font-medium" 
                      : "hover:bg-muted text-foreground/80"
                  }`}
                >
                  All Categories
                </button>
                {categories?.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.name)}
                    className={`text-left px-3 py-2 text-sm rounded-md transition-colors flex justify-between items-center ${
                      selectedCategory === cat.name 
                        ? "bg-primary/10 text-primary font-medium" 
                        : "hover:bg-muted text-foreground/80"
                    }`}
                  >
                    <span className="truncate pr-2">{cat.name}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold">
              {isLoadingDocs ? "Loading..." : `${documents?.length || 0} Results`}
            </h2>
            {selectedCategory && (
              <Badge variant="secondary" className="bg-primary/10 text-primary hover:bg-primary/20">
                {selectedCategory}
              </Badge>
            )}
          </div>

          {isLoadingDocs ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="flex flex-col space-y-3">
                  <Skeleton className="h-[180px] w-full rounded-xl" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-[80%]" />
                  <div className="pt-4 flex justify-between">
                    <Skeleton className="h-6 w-16" />
                    <Skeleton className="h-6 w-20" />
                  </div>
                </div>
              ))}
            </div>
          ) : documents?.length ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
              {documents.map((doc) => (
                <DocumentCard key={doc.id} document={doc} />
              ))}
            </div>
          ) : (
            <div className="py-20 text-center flex flex-col items-center justify-center border border-dashed border-border rounded-xl bg-muted/20">
              <Search className="h-12 w-12 text-muted-foreground/40 mb-4" />
              <h3 className="text-xl font-bold text-foreground mb-2">No documents found</h3>
              <p className="text-muted-foreground max-w-md">
                We couldn't find any resources matching your current filters. Try adjusting your search term or category.
              </p>
              {hasActiveFilters && (
                <Button onClick={handleClearFilters} variant="outline" className="mt-6">
                  Clear Filters
                </Button>
              )}
            </div>
          )}
        </main>
      </div>
    </PublicLayout>
  );
}

import { AdminLayout } from "@/components/layout/AdminLayout";
import { useRequestUploadUrl } from "@workspace/api-client-react";
import { useState, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { UploadCloud, File, CheckCircle, AlertCircle, X, Copy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Input } from "@/components/ui/input";

export default function AdminUpload() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [uploadedUrl, setUploadedUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const uploadUrlMutation = useRequestUploadUrl();

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedFile(e.target.files[0]);
      setError(null);
      setUploadedUrl(null);
      setProgress(0);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) return;

    setUploading(true);
    setProgress(10);
    setError(null);

    try {
      // 1. Get presigned URL
      const { uploadURL, objectPath } = await uploadUrlMutation.mutateAsync({
        data: {
          name: selectedFile.name,
          size: selectedFile.size,
          contentType: selectedFile.type || "application/octet-stream"
        }
      });

      setProgress(40);

      // 2. Upload file to presigned URL
      const xhr = new XMLHttpRequest();
      
      const uploadPromise = new Promise((resolve, reject) => {
        xhr.upload.addEventListener("progress", (event) => {
          if (event.lengthComputable) {
            const percentComplete = 40 + Math.round((event.loaded / event.total) * 60);
            setProgress(percentComplete);
          }
        });

        xhr.addEventListener("load", () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            resolve(true);
          } else {
            reject(new Error(`Upload failed with status ${xhr.status}`));
          }
        });

        xhr.addEventListener("error", () => reject(new Error("Network error during upload")));
        xhr.addEventListener("abort", () => reject(new Error("Upload aborted")));
      });

      xhr.open("PUT", uploadURL);
      xhr.setRequestHeader("Content-Type", selectedFile.type || "application/octet-stream");
      xhr.send(selectedFile);

      await uploadPromise;

      setProgress(100);
      
      // Compute final URL (this assumes the file is publicly accessible via an API endpoint or CDN)
      // Since objectPath is returned, we format it. The exact URL structure depends on backend,
      // but let's assume /api/storage/objectPath or just the object path itself.
      const finalUrl = `/api/storage/${objectPath}`;
      setUploadedUrl(finalUrl);
      
      toast({
        title: "Upload successful",
        description: "Your file is ready to use.",
      });

    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to upload file");
      toast({
        variant: "destructive",
        title: "Upload failed",
        description: err.message || "Failed to upload file",
      });
    } finally {
      setUploading(false);
    }
  };

  const resetForm = () => {
    setSelectedFile(null);
    setUploadedUrl(null);
    setProgress(0);
    setError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const copyUrl = () => {
    if (uploadedUrl) {
      navigator.clipboard.writeText(window.location.origin + uploadedUrl);
      toast({ title: "Copied to clipboard" });
    }
  };

  return (
    <AdminLayout>
      <div className="max-w-2xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Upload Files</h1>
          <p className="text-muted-foreground mt-1">Upload documents to cloud storage securely.</p>
        </div>

        <Card className="border-border/60 shadow-sm">
          <CardHeader>
            <CardTitle>File Uploader</CardTitle>
            <CardDescription>Select a file to upload. It will be securely stored.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {!selectedFile ? (
              <div 
                className="border-2 border-dashed border-border rounded-xl p-12 text-center hover:bg-muted/50 transition-colors cursor-pointer"
                onClick={() => fileInputRef.current?.click()}
              >
                <input 
                  type="file" 
                  className="hidden" 
                  ref={fileInputRef}
                  onChange={handleFileSelect}
                />
                <UploadCloud className="mx-auto h-12 w-12 text-muted-foreground/50 mb-4" />
                <h3 className="text-lg font-medium">Click to select a file</h3>
                <p className="text-sm text-muted-foreground mt-1">or drag and drop here</p>
              </div>
            ) : (
              <div className="border rounded-xl p-6 bg-muted/20">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center text-primary shrink-0">
                      <File className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <p className="font-medium text-sm truncate">{selectedFile.name}</p>
                      <p className="text-xs text-muted-foreground">{(selectedFile.size / 1024 / 1024).toFixed(2)} MB</p>
                    </div>
                  </div>
                  {!uploading && !uploadedUrl && (
                    <Button variant="ghost" size="icon" onClick={resetForm} className="text-muted-foreground">
                      <X className="w-4 h-4" />
                    </Button>
                  )}
                </div>

                {uploading && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Uploading...</span>
                      <span>{progress}%</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </div>
                )}

                {error && (
                  <div className="mt-4 p-3 bg-destructive/10 text-destructive text-sm rounded-md flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                    <p>{error}</p>
                  </div>
                )}

                {uploadedUrl && (
                  <div className="mt-4 space-y-3">
                    <div className="p-3 bg-secondary/10 text-secondary-foreground text-sm rounded-md flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-secondary shrink-0" />
                      <p className="font-medium">Upload complete!</p>
                    </div>
                    <div className="flex gap-2">
                      <Input value={uploadedUrl} readOnly className="bg-background text-xs font-mono" />
                      <Button variant="outline" size="icon" onClick={copyUrl} className="shrink-0">
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Use this URL when creating or editing a document.
                    </p>
                  </div>
                )}
              </div>
            )}
          </CardContent>
          <CardFooter className="flex justify-end gap-3 border-t bg-muted/20 px-6 py-4">
            {selectedFile && !uploading && !uploadedUrl && (
              <>
                <Button variant="outline" onClick={resetForm}>Cancel</Button>
                <Button onClick={handleUpload}>Upload File</Button>
              </>
            )}
            {uploadedUrl && (
              <Button onClick={resetForm}>Upload Another</Button>
            )}
          </CardFooter>
        </Card>
      </div>
    </AdminLayout>
  );
}

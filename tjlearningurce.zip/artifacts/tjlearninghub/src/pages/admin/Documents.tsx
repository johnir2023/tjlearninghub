import { AdminLayout } from "@/components/layout/AdminLayout";
import { useListDocuments, useDeleteDocument, getListDocumentsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Edit, Plus, Trash2, Search, FileText, CheckCircle2 } from "lucide-react";
import { formatPrice, formatDate } from "@/lib/format";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Skeleton } from "@/components/ui/skeleton";

export default function AdminDocuments() {
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [documentToDelete, setDocumentToDelete] = useState<number | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Debounce search
  import("react").then((React) => {
    React.useEffect(() => {
      const timer = setTimeout(() => {
        setDebouncedSearch(search);
      }, 500);
      return () => clearTimeout(timer);
    }, [search]);
  });

  const { data: documents, isLoading } = useListDocuments(
    { search: debouncedSearch || undefined },
    {
      query: {
        queryKey: getListDocumentsQueryKey({ search: debouncedSearch || undefined })
      }
    }
  );

  const deleteMutation = useDeleteDocument();

  const handleDelete = () => {
    if (!documentToDelete) return;
    
    deleteMutation.mutate({ id: documentToDelete }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListDocumentsQueryKey() });
        toast({ title: "Document deleted successfully" });
        setDocumentToDelete(null);
      },
      onError: (error) => {
        toast({
          variant: "destructive",
          title: "Failed to delete document",
          description: error.message
        });
        setDocumentToDelete(null);
      }
    });
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Documents</h1>
            <p className="text-muted-foreground mt-1">Manage the educational resources in your marketplace.</p>
          </div>
          <Link href="/admin/documents/new">
            <Button className="w-full sm:w-auto">
              <Plus className="w-4 h-4 mr-2" /> Add Document
            </Button>
          </Link>
        </div>

        <Card>
          <CardHeader className="pb-4">
            <div className="flex items-center space-x-2">
              <div className="relative flex-1 max-w-sm">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search documents..."
                  className="pl-9"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-3">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            ) : documents?.length === 0 ? (
              <div className="text-center py-12 border-2 border-dashed rounded-lg bg-muted/10">
                <FileText className="mx-auto h-12 w-12 text-muted-foreground/50 mb-4" />
                <h3 className="text-lg font-medium">No documents found</h3>
                <p className="text-muted-foreground mb-4">
                  {debouncedSearch ? "Try adjusting your search query." : "Get started by adding your first document."}
                </p>
                {!debouncedSearch && (
                  <Link href="/admin/documents/new">
                    <Button variant="outline">Create Document</Button>
                  </Link>
                )}
              </div>
            ) : (
              <div className="border rounded-md">
                <table className="w-full text-sm text-left">
                  <thead className="text-xs text-muted-foreground uppercase bg-muted/50 border-b">
                    <tr>
                      <th className="px-4 py-3 font-medium rounded-tl-md">Document Info</th>
                      <th className="px-4 py-3 font-medium">Category</th>
                      <th className="px-4 py-3 font-medium">Price</th>
                      <th className="px-4 py-3 font-medium">Stats</th>
                      <th className="px-4 py-3 font-medium">Status</th>
                      <th className="px-4 py-3 font-medium text-right rounded-tr-md">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {documents?.map((doc) => (
                      <tr key={doc.id} className="border-b last:border-0 hover:bg-muted/30 transition-colors">
                        <td className="px-4 py-3">
                          <div className="font-medium text-foreground">{doc.title}</div>
                          <div className="text-xs text-muted-foreground mt-1 truncate max-w-[200px]">
                            {doc.description}
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-primary/10 text-primary">
                            {doc.category}
                          </span>
                        </td>
                        <td className="px-4 py-3 font-mono font-medium">{formatPrice(doc.price)}</td>
                        <td className="px-4 py-3">
                          <div className="text-xs">
                            <span className="font-medium">{doc.downloadCount || 0}</span> downloads
                          </div>
                          <div className="text-xs text-muted-foreground mt-0.5">
                            {formatDate(doc.createdAt)}
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          {doc.featured ? (
                            <span className="inline-flex items-center text-xs font-medium text-accent">
                              <CheckCircle2 className="w-3 h-3 mr-1" /> Featured
                            </span>
                          ) : (
                            <span className="text-muted-foreground text-xs">Standard</span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Link href={`/admin/documents/${doc.id}/edit`}>
                              <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-primary">
                                <Edit className="h-4 w-4" />
                              </Button>
                            </Link>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                              onClick={() => setDocumentToDelete(doc.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        <AlertDialog open={!!documentToDelete} onOpenChange={(open) => !open && setDocumentToDelete(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
              <AlertDialogDescription>
                This action cannot be undone. This will permanently delete the document from the marketplace.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction 
                onClick={(e) => {
                  e.preventDefault();
                  handleDelete();
                }}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                {deleteMutation.isPending ? "Deleting..." : "Delete"}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </AdminLayout>
  );
}

import { AdminLayout } from "@/components/layout/AdminLayout";
import { useParams, useLocation } from "wouter";
import { useGetDocument, useCreateDocument, useUpdateDocument, useListCategories, getGetDocumentQueryKey } from "@workspace/api-client-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { ArrowLeft, Loader2, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { useEffect } from "react";

const documentSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  category: z.string().min(1, "Please select a category"),
  price: z.coerce.number().min(0, "Price must be positive"),
  thumbnailUrl: z.string().url("Must be a valid URL").optional().or(z.literal("")),
  fileUrl: z.string().url("Must be a valid URL").optional().or(z.literal("")),
  lipaLinkUrl: z.string().url("Must be a valid URL").min(1, "Payment link is required"),
  featured: z.boolean().default(false),
});

type DocumentFormValues = z.infer<typeof documentSchema>;

export default function DocumentForm() {
  const params = useParams();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const isEdit = !!params.id;
  const id = isEdit ? parseInt(params.id!) : 0;

  const { data: document, isLoading: isLoadingDoc } = useGetDocument(id, {
    query: {
      enabled: isEdit,
      queryKey: getGetDocumentQueryKey(id)
    }
  });

  const { data: categories, isLoading: isLoadingCats } = useListCategories();

  const createMutation = useCreateDocument();
  const updateMutation = useUpdateDocument();

  const form = useForm<DocumentFormValues>({
    resolver: zodResolver(documentSchema),
    defaultValues: {
      title: "",
      description: "",
      category: "",
      price: 0,
      thumbnailUrl: "",
      fileUrl: "",
      lipaLinkUrl: "",
      featured: false,
    },
  });

  useEffect(() => {
    if (isEdit && document) {
      form.reset({
        title: document.title,
        description: document.description,
        category: document.category,
        price: document.price,
        thumbnailUrl: document.thumbnailUrl || "",
        fileUrl: document.fileUrl || "",
        lipaLinkUrl: document.lipaLinkUrl,
        featured: document.featured || false,
      });
    }
  }, [isEdit, document, form]);

  const onSubmit = (data: DocumentFormValues) => {
    // Clean up empty strings
    const payload = {
      ...data,
      thumbnailUrl: data.thumbnailUrl || undefined,
      fileUrl: data.fileUrl || undefined,
    };

    if (isEdit) {
      updateMutation.mutate({ id, data: payload }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetDocumentQueryKey(id) });
          toast({ title: "Document updated successfully" });
          setLocation("/admin/documents");
        },
        onError: (err) => {
          toast({ variant: "destructive", title: "Update failed", description: err.message });
        }
      });
    } else {
      createMutation.mutate({ data: payload }, {
        onSuccess: () => {
          toast({ title: "Document created successfully" });
          setLocation("/admin/documents");
        },
        onError: (err) => {
          toast({ variant: "destructive", title: "Creation failed", description: err.message });
        }
      });
    }
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  if (isEdit && isLoadingDoc) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => setLocation("/admin/documents")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">
              {isEdit ? "Edit Document" : "Create New Document"}
            </h1>
            <p className="text-muted-foreground">
              {isEdit ? "Update details for this resource." : "Add a new resource to the marketplace."}
            </p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Document Details</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem className="col-span-1 md:col-span-2">
                        <FormLabel>Title</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. KCSE Biology Revision Notes" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem className="col-span-1 md:col-span-2">
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Detailed description of what is included in this document..." 
                            className="resize-none h-24"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="category"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Category</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value || undefined}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder={isLoadingCats ? "Loading..." : "Select a category"} />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {categories?.map((cat) => (
                              <SelectItem key={cat.id} value={cat.name}>
                                {cat.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="price"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Price (KES)</FormLabel>
                        <FormControl>
                          <Input type="number" min="0" placeholder="0" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="lipaLinkUrl"
                    render={({ field }) => (
                      <FormItem className="col-span-1 md:col-span-2">
                        <FormLabel>LipaLink / Payment URL</FormLabel>
                        <FormControl>
                          <Input placeholder="https://lipa.link/..." {...field} />
                        </FormControl>
                        <FormDescription>The external payment link users will be redirected to.</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="thumbnailUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Thumbnail URL (Optional)</FormLabel>
                        <FormControl>
                          <Input placeholder="https://..." {...field} value={field.value || ""} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="fileUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>File URL (Optional for now)</FormLabel>
                        <FormControl>
                          <Input placeholder="https://..." {...field} value={field.value || ""} />
                        </FormControl>
                        <FormDescription>Where the actual file is hosted.</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="featured"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4 col-span-1 md:col-span-2">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Featured Document</FormLabel>
                          <FormDescription>
                            Show this document on the homepage featured section.
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>

                <div className="flex justify-end gap-4 pt-4 border-t">
                  <Button type="button" variant="outline" onClick={() => setLocation("/admin/documents")}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={isPending}>
                    {isPending ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Save className="w-4 h-4 mr-2" />
                    )}
                    {isEdit ? "Update Document" : "Create Document"}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}

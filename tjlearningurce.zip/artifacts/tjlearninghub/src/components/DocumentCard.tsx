import { Link } from "wouter";
import { formatPrice } from "@/lib/format";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Download } from "lucide-react";
import type { Document } from "@workspace/api-client-react/src/generated/api.schemas";

export function DocumentCard({ document }: { document: Document }) {
  return (
    <Card className="flex flex-col overflow-hidden hover-elevate transition-all duration-300">
      <div className="relative aspect-video w-full bg-muted overflow-hidden flex items-center justify-center">
        {document.thumbnailUrl ? (
          <img 
            src={document.thumbnailUrl} 
            alt={document.title}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center p-4 text-center">
            <span className="text-primary font-medium opacity-50 text-lg uppercase tracking-wider">{document.category}</span>
          </div>
        )}
        {document.featured && (
          <Badge className="absolute top-2 right-2 bg-accent text-accent-foreground hover:bg-accent/90 border-none shadow-sm">
            Featured
          </Badge>
        )}
      </div>
      <CardHeader className="p-4 pb-2">
        <div className="flex justify-between items-start gap-2 mb-1">
          <Badge variant="outline" className="text-xs font-normal text-muted-foreground border-border/50">
            {document.category}
          </Badge>
          <span className="text-accent font-bold font-mono">{formatPrice(document.price)}</span>
        </div>
        <h3 className="font-bold text-lg leading-tight line-clamp-2 text-foreground" title={document.title}>
          {document.title}
        </h3>
      </CardHeader>
      <CardContent className="p-4 pt-0 flex-grow">
        <p className="text-muted-foreground text-sm line-clamp-2" title={document.description}>
          {document.description}
        </p>
      </CardContent>
      <CardFooter className="p-4 pt-0 mt-auto">
        <a href={document.lipaLinkUrl} target="_blank" rel="noopener noreferrer" className="w-full">
          <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold">
            <Download className="w-4 h-4 mr-2" />
            Buy Now
          </Button>
        </a>
      </CardFooter>
    </Card>
  );
}

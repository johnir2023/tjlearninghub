import { Link, useLocation } from "wouter";
import { useEffect } from "react";
import { useGetAdminSession, useAdminLogout, getGetAdminSessionQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { LayoutDashboard, FileText, FolderTree, Upload, LogOut, Loader2, BookOpen } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";

export function AdminLayout({ children }: { children: React.ReactNode }) {
  const [, setLocation] = useLocation();
  const [locationPath] = useLocation();
  const queryClient = useQueryClient();
  
  const { data: session, isLoading, isError } = useGetAdminSession({
    query: {
      retry: false,
      staleTime: 5 * 60 * 1000, // 5 minutes
    }
  });

  const logoutMutation = useAdminLogout();

  useEffect(() => {
    if (!isLoading && (!session?.authenticated || isError)) {
      setLocation("/admin/login");
    }
  }, [session, isLoading, isError, setLocation]);

  const handleLogout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetAdminSessionQueryKey() });
        setLocation("/admin/login");
      }
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!session?.authenticated) {
    return null; // Will redirect in useEffect
  }

  const navItems = [
    { href: "/admin/dashboard", icon: LayoutDashboard, label: "Dashboard" },
    { href: "/admin/documents", icon: FileText, label: "Documents" },
    { href: "/admin/categories", icon: FolderTree, label: "Categories" },
    { href: "/admin/upload", icon: Upload, label: "Upload Files" },
  ];

  return (
    <div className="min-h-[100dvh] flex bg-background">
      {/* Sidebar */}
      <aside className="w-64 border-r border-border bg-sidebar text-sidebar-foreground flex flex-col hidden md:flex">
        <div className="h-16 flex items-center px-6 border-b border-sidebar-border bg-sidebar-primary/5">
          <Link href="/" className="flex items-center gap-2 text-sidebar-primary hover:text-sidebar-primary/80 transition-colors">
            <BookOpen className="h-6 w-6" />
            <span className="font-bold text-lg">TJLearningHub</span>
          </Link>
        </div>
        
        <ScrollArea className="flex-1 py-6 px-4">
          <div className="space-y-1">
            <div className="px-2 mb-4 text-xs font-semibold text-sidebar-foreground/50 uppercase tracking-wider">
              Administration
            </div>
            {navItems.map((item) => {
              const isActive = locationPath.startsWith(item.href) && 
                (item.href === "/admin/dashboard" ? locationPath === "/admin/dashboard" : true);
              
              return (
                <Link key={item.href} href={item.href}>
                  <div className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors cursor-pointer ${
                    isActive 
                      ? "bg-sidebar-primary text-sidebar-primary-foreground font-medium shadow-sm" 
                      : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                  }`}>
                    <item.icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </div>
                </Link>
              );
            })}
          </div>
        </ScrollArea>

        <div className="p-4 border-t border-sidebar-border">
          <div className="flex items-center gap-3 px-3 py-2 mb-2">
            <div className="w-8 h-8 rounded-full bg-sidebar-primary/20 flex items-center justify-center text-sidebar-primary font-bold">
              {session.username.charAt(0).toUpperCase()}
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-medium leading-none">{session.username}</span>
              <span className="text-xs text-sidebar-foreground/60">Administrator</span>
            </div>
          </div>
          <Button 
            variant="ghost" 
            className="w-full justify-start text-sidebar-foreground/80 hover:text-destructive hover:bg-destructive/10" 
            onClick={handleLogout}
            disabled={logoutMutation.isPending}
          >
            {logoutMutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <LogOut className="w-4 h-4 mr-2" />}
            Logout
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Mobile Header */}
        <header className="md:hidden h-16 border-b border-border flex items-center justify-between px-4 bg-background">
          <div className="flex items-center gap-2 text-primary">
            <BookOpen className="h-5 w-5" />
            <span className="font-bold">Admin</span>
          </div>
          {/* Very basic mobile nav - in a real app, use a Sheet component similar to public nav */}
          <Button variant="ghost" size="sm" onClick={handleLogout}>Logout</Button>
        </header>

        <ScrollArea className="flex-1">
          <div className="p-6 lg:p-8 max-w-6xl mx-auto w-full">
            {children}
          </div>
        </ScrollArea>
      </main>
    </div>
  );
}

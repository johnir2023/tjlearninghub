import { Switch, Route, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

// Public pages
import Home from "@/pages/Home";
import Marketplace from "@/pages/Marketplace";
import Download from "@/pages/Download";

// Admin pages
import AdminLogin from "@/pages/admin/Login";
import AdminDashboard from "@/pages/admin/Dashboard";
import AdminDocuments from "@/pages/admin/Documents";
import DocumentForm from "@/pages/admin/DocumentForm";
import AdminCategories from "@/pages/admin/Categories";
import AdminUpload from "@/pages/admin/Upload";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      {/* Public Routes */}
      <Route path="/" component={Home} />
      <Route path="/marketplace" component={Marketplace} />
      <Route path="/download/:token" component={Download} />
      
      {/* Admin Routes */}
      <Route path="/admin">
        <Redirect to="/admin/dashboard" />
      </Route>
      <Route path="/admin/login" component={AdminLogin} />
      <Route path="/admin/dashboard" component={AdminDashboard} />
      <Route path="/admin/documents" component={AdminDocuments} />
      <Route path="/admin/documents/new" component={DocumentForm} />
      <Route path="/admin/documents/:id/edit" component={DocumentForm} />
      <Route path="/admin/categories" component={AdminCategories} />
      <Route path="/admin/upload" component={AdminUpload} />
      
      {/* 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;

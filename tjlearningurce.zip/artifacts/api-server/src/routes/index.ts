import { Router, type IRouter } from "express";
import healthRouter from "./health";
import documentsRouter from "./documents";
import categoriesRouter from "./categories";
import adminRouter from "./admin";
import downloadsRouter from "./downloads";
import statsRouter from "./stats";
import storageRouter from "./storage";

const router: IRouter = Router();

router.use(healthRouter);
router.use(documentsRouter);
router.use(categoriesRouter);
router.use(adminRouter);
router.use(downloadsRouter);
router.use(statsRouter);
router.use(storageRouter);

export default router;

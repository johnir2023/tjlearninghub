import { Router, type IRouter } from "express";
import { AdminLoginBody } from "@workspace/api-zod";

const router: IRouter = Router();

const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "tjlearning2024";

router.post("/admin/login", async (req, res): Promise<void> => {
  const parsed = AdminLoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { username, password } = parsed.data;

  if (username !== ADMIN_USERNAME || password !== ADMIN_PASSWORD) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }

  req.session!.admin = true;
  req.session!.username = username;

  res.json({ authenticated: true, username });
});

router.post("/admin/logout", async (req, res): Promise<void> => {
  req.session = null;
  res.sendStatus(204);
});

router.get("/admin/session", async (req, res): Promise<void> => {
  if (!req.session?.admin) {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }

  res.json({ authenticated: true, username: req.session.username as string });
});

export default router;

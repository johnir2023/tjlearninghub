import { Router, type IRouter } from "express";
import { desc } from "drizzle-orm";
import { db, documentsTable, categoriesTable } from "@workspace/db";
import { sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/stats", async (req, res): Promise<void> => {
  if (!req.session?.admin) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const [docStats] = await db
    .select({
      totalDocuments: sql<number>`count(*)::int`,
      totalDownloads: sql<number>`sum(${documentsTable.downloadCount})::int`,
    })
    .from(documentsTable);

  const [catStats] = await db
    .select({
      totalCategories: sql<number>`count(*)::int`,
    })
    .from(categoriesTable);

  const recentDocs = await db
    .select()
    .from(documentsTable)
    .orderBy(desc(documentsTable.createdAt))
    .limit(5);

  res.json({
    totalDocuments: docStats?.totalDocuments ?? 0,
    totalDownloads: docStats?.totalDownloads ?? 0,
    totalCategories: catStats?.totalCategories ?? 0,
    recentDocuments: recentDocs.map(d => ({
      ...d,
      price: parseFloat(d.price as unknown as string),
    })),
  });
});

export default router;

import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, documentsTable, downloadTokensTable } from "@workspace/db";
import { GetDownloadParams } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/downloads/:token", async (req, res): Promise<void> => {
  const params = GetDownloadParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const { token } = params.data;

  const [tokenRecord] = await db
    .select()
    .from(downloadTokensTable)
    .where(eq(downloadTokensTable.token, token));

  if (!tokenRecord) {
    res.status(403).json({ error: "Invalid or expired download token" });
    return;
  }

  const [doc] = await db
    .select()
    .from(documentsTable)
    .where(eq(documentsTable.id, tokenRecord.documentId));

  if (!doc) {
    res.status(404).json({ error: "Document not found" });
    return;
  }

  if (!doc.fileUrl) {
    res.status(404).json({ error: "Document file not available" });
    return;
  }

  await db
    .update(documentsTable)
    .set({ downloadCount: doc.downloadCount + 1 })
    .where(eq(documentsTable.id, doc.id));

  await db
    .update(downloadTokensTable)
    .set({ usedAt: new Date() })
    .where(eq(downloadTokensTable.token, token));

  res.json({
    documentId: doc.id,
    title: doc.title,
    fileUrl: doc.fileUrl,
    thumbnailUrl: doc.thumbnailUrl ?? null,
  });
});

export default router;

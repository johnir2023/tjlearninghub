import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { documentsTable } from "./documents";

export const downloadTokensTable = pgTable("download_tokens", {
  id: serial("id").primaryKey(),
  token: text("token").notNull().unique(),
  documentId: integer("document_id").notNull().references(() => documentsTable.id, { onDelete: "cascade" }),
  usedAt: timestamp("used_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type DownloadToken = typeof downloadTokensTable.$inferSelect;
